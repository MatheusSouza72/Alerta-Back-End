package com.pi.DefesaCivil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DefesaCivilApplication {

	public static void main(String[] args) {
		SpringApplication.run(DefesaCivilApplication.class, args);
	}

}
