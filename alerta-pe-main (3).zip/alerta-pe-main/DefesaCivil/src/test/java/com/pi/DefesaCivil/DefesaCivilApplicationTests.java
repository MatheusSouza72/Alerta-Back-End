package com.pi.DefesaCivil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DefesaCivilApplicationTests {

	@Test
	void contextLoads() {
	}

}
