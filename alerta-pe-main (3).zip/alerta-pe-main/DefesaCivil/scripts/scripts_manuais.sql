insert into administrador(cargo, email, login, nome_completo, senha) values ('Diretor geral', 'fulaninho@email.com', 'M5684', 'Fulano da Silva', 'teste123');

select * from administrador ;

delete from administrador where id_admin = 3;

select * from usuario;